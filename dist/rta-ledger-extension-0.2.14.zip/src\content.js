/*
 * Content script (isolated world). Bridges messages from src/inject.js, accumulates battle lists
 * PER PLAYER (the match history is a SPA — switching players changes the URL without a reload),
 * reads the player card from the page DOM, and drives the overlay UI.
 */
(function () {
	'use strict';

	var store = {};              // "world:nick" -> { battles: { seq: raw } }
	var currentKey = null;
	var lastPath;                // undefined until the first route sync
	var syncing = false;
	var overlay = null;
	var fab = null;
	var mounted = false;
	var observer = null;

	/* ---------- route / player scoping ---------- */
	function pathInfo() {
		var m = /\/gg\/battlerecord\/([^/]+)\/(\d+)/.exec(location.pathname);
		return m ? { key: m[1] + ':' + m[2], world: m[1], nick: m[2] } : null;
	}
	function isBattleRecord() { return !!pathInfo(); }
	function bucketOf(key) { if (!key) return null; return store[key] || (store[key] = { battles: {} }); }
	function countFor(key) { var b = key && store[key]; return b ? Object.keys(b.battles).length : 0; }
	function rawFor(key) {
		var b = key && store[key];
		if (!b) return [];
		var out = [];
		for (var k in b.battles) out.push(b.battles[k]);
		return out;
	}
	function keyOf(raw) {
		return (raw.worldCode || '?') + ':' + (raw.nicknameno != null ? String(raw.nicknameno) : '?');
	}

	/* ---------- bridge ---------- */
	window.addEventListener('message', function (ev) {
		if (ev.source !== window) return;
		var d = ev.data;
		if (!d || d.__e7rta !== true || d.type === 'ready') return;
		if (d.type === 'battles') ingest(d.payload);
		else if (d.type === 'navigate') syncRoute();
		else if (d.type === 'syncStart') { syncing = true; paintFab(); }
		else if (d.type === 'syncDone' || d.type === 'syncError') { syncing = false; paintFab(); }
	});

	function ingest(payload) {
		var list = (payload && payload.battles) || [];
		var touched = {};
		for (var i = 0; i < list.length; i++) {
			var b = list[i];
			if (!b || b.battle_seq == null) continue;
			var key = keyOf(b);
			bucketOf(key).battles[String(b.battle_seq)] = b;
			touched[key] = true;
		}
		if (!currentKey) { var keys = Object.keys(touched); if (keys.length) currentKey = keys[0]; }
		ensureFab();
		paintFab();
		// only repaint if the batch belongs to the player we are showing (avoids cross-player flicker)
		if (overlay && !overlay.hidden && Object.prototype.hasOwnProperty.call(touched, currentKey)) refresh();
	}

	/** Route changed (SPA navigation): reset the view onto the new player. */
	function syncRoute() {
		var info = pathInfo();
		var key = info ? info.key : null;
		var changed = key !== lastPath;
		lastPath = key;
		if (key) currentKey = key;
		ensureFab();
		paintFab();
		if (changed) {
			attachProfileObserver();
			if (overlay && !overlay.hidden) refresh();
		}
	}

	/* ---------- player card from the page ---------- */
	function readProfile() {
		var ui = document.querySelector('#userInfo');
		if (!ui) return null;
		var nick = ui.querySelector('.info-box .nickname');
		var name = nick ? (nick.childNodes[0] && nick.childNodes[0].textContent || '').trim() : '';
		var serv = ui.querySelector('.serv span');
		var clan = ui.querySelector('.clan');
		var tier = ui.querySelector('.tier-name');
		var score = ui.querySelector('.score-rate');
		var emblemEl = ui.querySelector('.img-box em');
		var avatar = ui.querySelector('.profile-img img');

		var emblem = '';
		if (emblemEl) {
			var bg = getComputedStyle(emblemEl).backgroundImage || '';
			var m = /url\(["']?([^"')]+)["']?\)/.exec(bg);
			if (m) emblem = m[1];
		}
		return {
			name: name || null,
			server: serv ? serv.textContent.trim() : null,
			clan: clan ? clan.textContent.replace(/\s+/g, ' ').trim() : null,
			tier: tier ? tier.textContent.trim() : null,
			score: score ? score.innerText.replace(/\s+/g, ' ').trim() : null,
			emblem: emblem || null,
			avatar: avatar && avatar.src ? avatar.src : null
		};
	}
	/* Vue swaps #userInfo on navigation, so re-target the observer each time. */
	function attachProfileObserver() {
		if (observer) { observer.disconnect(); observer = null; }
		var ui = document.querySelector('#userInfo');
		if (!ui) return;
		observer = new MutationObserver(function () { if (overlay && !overlay.hidden) refresh(); });
		observer.observe(ui, { childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'class', 'style'] });
	}

	/* ---------- floating button ---------- */
	function ensureFab() {
		if (fab || !document.body || !isBattleRecord()) return;
		fab = document.createElement('button');
		fab.type = 'button';
		fab.className = 'e7rta-fab';
		fab.addEventListener('click', open);
		document.body.appendChild(fab);
		paintFab();
	}
	function paintFab() {
		if (!fab) return;
		var on = isBattleRecord();
		fab.style.display = on ? '' : 'none';
		if (!on) return;
		var n = countFor(currentKey);
		fab.innerHTML = '<span class="e7rta-fab-dot"></span><span class="e7rta-fab-label">RTA Ledger</span><span class="e7rta-fab-count">' + (syncing ? '…' : n) + '</span>';
		fab.title = n ? n + ' games captured for this player — open the analysis' : 'Waiting for this player\'s match history…';
	}

	/* ---------- overlay ---------- */
	function open() {
		if (!overlay) buildOverlay();
		overlay.hidden = false;
		document.documentElement.classList.add('e7rta-lock');
		var info = pathInfo();
		if (info) { currentKey = info.key; if (lastPath === undefined) lastPath = info.key; }
		attachProfileObserver();
		refresh();
	}
	function close() {
		if (overlay) overlay.hidden = true;
		document.documentElement.classList.remove('e7rta-lock');
	}
	function buildOverlay() {
		overlay = document.createElement('div');
		overlay.className = 'e7rta-overlay';
		overlay.setAttribute('role', 'dialog');
		overlay.setAttribute('aria-modal', 'true');
		overlay.setAttribute('aria-label', 'RTA Ledger performance analysis');
		var card = document.createElement('div');
		card.className = 'e7rta-card-host';
		overlay.appendChild(card);
		document.body.appendChild(overlay);
		window.E7Render.mount(card, { onClose: close });
		mounted = true;
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && overlay && !overlay.hidden) close(); });
		overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
	}
	function refresh() {
		if (!mounted) return;
		var data = window.E7Aggregate.build(rawFor(currentKey), { gapMinutes: 60 });
		window.E7Render.update(data, readProfile());
	}

	/* ---------- boot ---------- */
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { ensureFab(); syncRoute(); });
	else { ensureFab(); syncRoute(); }
	// fallback poll in case a navigation slips past the history hooks
	setInterval(function () { if (fab) syncRoute(); }, 1000);
})();
