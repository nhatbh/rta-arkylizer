/*
 * Bilingual UI strings for the RTA Ledger overlay (English / Vietnamese).
 * Flat dotted keys, {name} placeholders substituted at call time.
 * A missing key falls back to English and then to the key itself, so a gap in the
 * dictionary never renders a blank label.
 */
window.E7I18n = (function () {
	var LANGS = ['en', 'vi'];
	var LANG = 'en';
	var STORE = 'e7rta-lang';
	var listeners = [];

	var DICT = {
		en: {
			/* launcher */
			'fab.analyze': 'Analyze',
			'fab.title': '{n} games captured for this player — open the analysis',
			'fab.waiting': 'Waiting for this player\'s match history…',

			/* banners + chrome */
			'sub.gamesCaptured': '{n} games captured',
			'banner.unranked': 'Unranked',
			'banner.player': 'Player {n}',
			'banner.unknown': 'Unknown player',
			'season.all': 'All seasons',
			'season.label': 'Season',
			'unit.pts': 'pts',
			'unit.games': 'games',
			'unit.turns': 'turns',
			'unit.win': 'win',
			'lang.label': 'Language',
			'close.label': 'Close analysis',
			'overlay.label': 'RTA Ledger performance analysis',

			/* cards */
			'card.summary': 'Season summary',
			'card.tags': 'Tags',
			'card.recentForm': 'Recent form',
			'card.sessions': 'Sessions',
			'card.rankPoints': 'Rank points',
			'card.journey': 'Ranked journey',

			/* tabs */
			'tab.matches': 'Matches',
			'tab.heroes': 'Heroes',
			'tab.sessions': 'Sessions',

			/* matches tab */
			'match.win': 'Victory',
			'match.loss': 'Defeat',
			'match.vs': 'VS',
			'match.none': 'No matches in this view.',
			'match.more': 'Show more',
			'match.turnsN': 'Turns {n}',
			'match.timeN': 'Time {t}',
			'match.banned': 'Banned',
			'match.myTeam': 'Your team',
			'match.foeTeam': 'Opponent',
			'match.dmgShort': 'dmg',
			'match.scoreLine': '{from} → {to}',
			'match.delta': 'Point swing',
			'match.firstPick': 'First pick',
			'match.openMatch': 'Expand match',
			'match.order': '{n} matches, newest first',

			/* subs + hints */
			'sub.lastGames': 'last {n} games',
			'sub.lastMatches': 'last {n}',
			'sub.sessionsHint': 'Click a bar to inspect that session on the Sessions tab.',

			/* summary rows */
			'sum.record': 'Record',
			'sum.winRate': 'Win rate',
			'sum.net': 'Net points',
			'sum.score': 'Current score',
			'sum.peakLow': 'Peak / low',
			'sum.sessions': 'Sessions',

			/* recent-form tiles */
			'box.winRate': 'Win rate',
			'box.net': 'Net points',
			'box.avg': 'Avg / game',
			'box.streak': 'Streak',

			/* playstyle knobs */
			'knob.lineup': 'Lineup',
			'knob.length': 'Match length',
			'knob.turn': 'Opening turn',
			'knob.forcer': 'Forcer',
			'knob.flexible': 'Flexible',
			'knob.siege': 'Siege',
			'knob.blitz': 'Blitz',
			'knob.reaction': 'Reaction',
			'knob.initiative': 'Initiative',
			'knob.lineupNote': '{v}% fresh lineups (n={n})',
			'knob.noneGames': 'not enough games',
			'knob.lengthNote': 'avg {turns} turns · 15 is the midpoint',
			'knob.noTurns': 'no turn data',
			'knob.turnNote': '{v}% opening turns held (n={n})',
			'knob.noGauge': 'no energy-gauge data',

			/* hero tab */
			'hero.byRecord': 'Heroes by record',
			'hero.ledger': 'Hero ledger',
			'hero.usedThisSession': 'Heroes used this session',
			'hero.warmup': 'Warm-up & fatigue',
			'hero.gameByGame': 'Game by game',
			'hero.itemSets': 'Item sets',
			'hero.artifacts': 'Artifacts',
			'hero.pickPosition': 'Pick position',
			'hero.firstVsSecond': 'First vs second pick',
			'hero.usedNote': '{heroes} distinct heroes across {games} games this session — hover a bar for the record.',
			'hero.slotsAxis': 'games drafted',
			'hero.record': '{games} games · {pct}% win',
			'hero.split': '{w}W-{l}L',
			'hero.avgLine': 'avg {dmg} dmg · {pts} pts',
			'hero.slotTip': '{games} games · {pct}% win ({w}W-{l}L)',
			'hero.fpTip': '{pct}% win over {games} games',
			'hero.warmupNote': 'Win rate by how many games into a session you are, across every session in this view.',
			'hero.message': 'Match {i}',
			'hero.ptsRank': '{score} pts · {rank}',
			'hero.winRateWindow': '{n}-game win rate {pct}%',
			'hero.fpYou': 'You open',
			'hero.fpThey': 'They open',

			/* session tab */
			'sess.none': 'No sessions in this view.',
			'sess.header': 'Session {i} of {n} · {date} {from}–{to}',
			'sess.scoreNote': 'Score after each game in this session · click a bar in the Sessions panel to switch.',
			'sess.games': 'Games',
			'sess.record': 'Record',
			'sess.winRate': 'Win rate',
			'sess.net': 'Net points',
			'sess.length': 'Length',
			'sess.score': 'Score',
			'sess.minutes': '{n} min',
			'sess.gameN': 'Game {n}',
			'sess.axis': 'game in session',
			'sess.playedWin': 'WIN',
			'sess.playedLoss': 'LOSS',
			'sess.result': 'Result',
			'sess.points': 'Points',
			'sess.turns': 'Turns',
			'sess.team': 'Team',

			/* table + detail */
			't.hero': 'Hero',
			't.games': 'Games',
			't.winPct': 'Win %',
			't.mvpPct': 'MVP %',
			't.avgDmg': 'Avg dmg',
			't.avgTaken': 'Avg taken',
			't.avgHeal': 'Avg heal',
			't.kills': 'Kills',
			't.slot': 'Slot',
			't.cr': 'CR',
			't.sets': 'Sets',
			't.artifact': 'Artifact',
			'd.win': 'Win rate',
			'd.mvp': 'MVP',
			'd.avgPts': 'Avg pts',
			'd.pick': 'Pick',
			'd.ban': 'Ban',
			'd.dmg': 'Damage',
			'd.taken': 'Damage taken',
			'd.heal': 'Healing',
			'd.respawns': 'Respawns',
			'd.winShort': 'Win',
			'd.kills': 'Kills',
			'd.cr': 'Avg CR',
			'd.noSets': 'No set data for this hero.',
			'd.noArtifacts': 'No artifact data for this hero.',
			'd.iconMeta': '{games} games · {pct}%',
			'hero.firstPick': 'First pick',
			'hero.secondPick': 'Second pick',

			/* chips */
			'chip.noSessions': 'No sessions',
			'chip.sessions': 'Sessions',
			'chip.avgLength': 'Avg length',
			'chip.best': 'Best',
			'chip.toughest': 'Toughest',
			'unit.minShort': 'm',
			'chip.session': 'S{i} · {w}W-{l}L · {pct}% · net {net}',

			/* empty state */
			'empty.title': 'No ranked battles captured for this player yet.',
			'empty.hint': 'Give the match history a moment to load, or open a different player.',

			/* analysis tags */
			'tag.initiative.label': 'Initiative', 'tag.initiative.detail': 'You take the opening turn in {v}% of games (n={n}) — your side wins the speed race off the energy gauge.',
			'tag.reaction.label': 'Reaction', 'tag.reaction.detail': 'You usually move second ({v}% opening turns, n={n}). You play from behind on the tempo axis.',
			'tag.coinflip.label': 'Coin Flip on Turn 1', 'tag.coinflip.detail': 'Opening turn is a coin flip ({v}% initiative, n={n}).',
			'tag.secondWind.label': 'Second Wind', 'tag.secondWind.detail': 'You win {op}% when the opponent opens vs {me}% when you do — you are stronger reacting than dictating.',
			'tag.frontRunner.label': 'Front Runner', 'tag.frontRunner.detail': 'You win {me}% when you pick first vs {op}% when the opponent does — dictating the draft pays.',
			'tag.draftAgnostic.label': 'Draft Agnostic', 'tag.draftAgnostic.detail': 'First pick barely moves your win rate ({me}% vs {op}%).',
			'tag.heroGod.label': '{hero} God', 'tag.heroGod.detail': '{hero}: {pct}% win rate over {games} games ({mvp}% MVP). Your most reliable pick.',
			'tag.heroTrap.label': '{hero} Trap', 'tag.heroTrap.detail': '{hero}: only {pct}% over {games} games. High usage, poor return — bench it.',
			'tag.chameleon.label': 'Chameleon', 'tag.chameleon.detail': 'You changed at least 3 heroes in {v}% of consecutive games (n={n}) — hard to draft against.',
			'tag.oneTrick.label': 'One-Trick', 'tag.oneTrick.detail': 'Only {v}% of games swapped the lineup (n={n}). You force your comp and dare them to stop it.',
			'tag.blitz.label': 'Blitz Merchant', 'tag.blitz.detail': 'Tempo score {v}/100 — games average {turns} turns (15 is the midpoint). You win fast or not at all.',
			'tag.ironWall.label': 'Iron Wall', 'tag.ironWall.detail': 'Tempo score {v}/100 — games average {turns} turns. You grind them out.',
			'tag.slowStarter.label': 'Slow Starter', 'tag.slowStarter.detail': 'First 4 games of a session: {open}% vs {overall}% overall. You need a warm-up game before you click.',
			'tag.fastStarter.label': 'Fast Starter', 'tag.fastStarter.detail': 'First 4 games of a session: {open}% vs {overall}% overall. Sharp from game one.',
			'tag.marathon.label': 'Marathon', 'tag.marathon.detail': 'Games 20+ into a session: {pct}% (n={n}). You get better the longer you play.',
			'tag.primeTime.label': 'Prime Time', 'tag.primeTime.detail': '{pct}% win rate in the {hour}:00 hour (n={n}).',
			'tag.roughDay.label': 'Rough {day}', 'tag.roughDay.detail': '{day} games run {pct}% (n={n}) vs {overall}% overall.',
			'tag.heater.label': 'Heater', 'tag.heater.detail': 'Best run this season: {n} straight wins.',
			'tag.tilt.label': 'Tilt Spiral', 'tag.tilt.detail': 'Worst run: {n} straight losses. Worth a hard stop after 3.',
			'tag.economy.label': 'Point Economy', 'tag.economy.detail': 'Wins bank +{win}, losses cost {loss}. Net {net} over the season.',

			/* dates */
			'day.0': 'Sunday', 'day.1': 'Monday', 'day.2': 'Tuesday', 'day.3': 'Wednesday', 'day.4': 'Thursday', 'day.5': 'Friday', 'day.6': 'Saturday',
			'month.0': 'Jan', 'month.1': 'Feb', 'month.2': 'Mar', 'month.3': 'Apr', 'month.4': 'May', 'month.5': 'Jun',
			'month.6': 'Jul', 'month.7': 'Aug', 'month.8': 'Sep', 'month.9': 'Oct', 'month.10': 'Nov', 'month.11': 'Dec'
		},
		vi: {
			/* launcher */
			'fab.analyze': 'Phân tích',
			'fab.title': 'Đã ghi nhận {n} trận của người chơi này — mở phân tích',
			'fab.waiting': 'Đang chờ lịch sử đấu của người chơi này…',

			/* banners + chrome */
			'sub.gamesCaptured': '{n} trận đã ghi nhận',
			'banner.unranked': 'Chưa xếp hạng',
			'banner.player': 'Người chơi {n}',
			'banner.unknown': 'Không rõ người chơi',
			'season.all': 'Tất cả mùa',
			'season.label': 'Mùa',
			'unit.pts': 'điểm',
			'unit.games': 'trận',
			'unit.turns': 'lượt',
			'unit.win': 'thắng',
			'lang.label': 'Ngôn ngữ',
			'close.label': 'Đóng phân tích',
			'overlay.label': 'Phân tích phong độ RTA Ledger',

			/* cards */
			'card.summary': 'Tổng kết mùa',
			'card.tags': 'Nhãn',
			'card.recentForm': 'Phong độ gần đây',
			'card.sessions': 'Phiên đấu',
			'card.rankPoints': 'Điểm xếp hạng',
			'card.journey': 'Hành trình xếp hạng',

			/* tabs */
			'tab.matches': 'Trận đấu',
			'tab.heroes': 'Tướng',
			'tab.sessions': 'Phiên đấu',

			/* matches tab */
			'match.win': 'Thắng',
			'match.loss': 'Thua',
			'match.vs': 'VS',
			'match.none': 'Không có trận nào trong mùa này.',
			'match.more': 'Xem thêm',
			'match.turnsN': '{n} lượt',
			'match.timeN': 'Thời gian {t}',
			'match.banned': 'Bị cấm',
			'match.myTeam': 'Đội của bạn',
			'match.foeTeam': 'Đối thủ',
			'match.dmgShort': 'ST',
			'match.scoreLine': '{from} → {to}',
			'match.delta': 'Chênh điểm',
			'match.firstPick': 'Chọn trước',
			'match.openMatch': 'Mở rộng trận',
			'match.order': '{n} trận, mới nhất trước',

			/* subs + hints */
			'sub.lastGames': '{n} trận gần nhất',
			'sub.lastMatches': '{n} trận gần nhất',
			'sub.sessionsHint': 'Bấm vào một cột để xem phiên đó ở tab Phiên đấu.',

			/* summary rows */
			'sum.record': 'Thành tích',
			'sum.winRate': 'Tỷ lệ thắng',
			'sum.net': 'Điểm ròng',
			'sum.score': 'Điểm hiện tại',
			'sum.peakLow': 'Cao nhất / thấp nhất',
			'sum.sessions': 'Số phiên',

			/* recent-form tiles */
			'box.winRate': 'Tỷ lệ thắng',
			'box.net': 'Điểm ròng',
			'box.avg': 'TB / trận',
			'box.streak': 'Chuỗi',

			/* playstyle knobs */
			'knob.lineup': 'Đội hình',
			'knob.length': 'Độ dài trận',
			'knob.turn': 'Lượt mở màn',
			'knob.forcer': 'Ép bài',
			'knob.flexible': 'Linh hoạt',
			'knob.siege': 'Dài hơi',
			'knob.blitz': 'Thần tốc',
			'knob.reaction': 'Bị động',
			'knob.initiative': 'Chủ động',
			'knob.lineupNote': '{v}% đội hình mới (n={n})',
			'knob.noneGames': 'chưa đủ trận',
			'knob.lengthNote': 'trung bình {turns} lượt · mốc giữa là 15',
			'knob.noTurns': 'không có dữ liệu lượt',
			'knob.turnNote': 'giữ lượt mở màn {v}% (n={n})',
			'knob.noGauge': 'không có dữ liệu thanh năng lượng',

			/* hero tab */
			'hero.byRecord': 'Tướng theo thành tích',
			'hero.ledger': 'Bảng tướng',
			'hero.usedThisSession': 'Tướng dùng trong phiên này',
			'hero.warmup': 'Khởi động & mệt mỏi',
			'hero.gameByGame': 'Từng trận',
			'hero.itemSets': 'Bộ trang bị',
			'hero.artifacts': 'Artifacts',
			'hero.pickPosition': 'Vị trí chọn',
			'hero.firstVsSecond': 'Chọn trước và chọn sau',
			'hero.usedNote': '{heroes} tướng khác nhau trong {games} trận của phiên này — rê chuột lên cột để xem thành tích.',
			'hero.slotsAxis': 'số trận được chọn',
			'hero.record': '{games} trận · thắng {pct}%',
			'hero.split': '{w}T-{l}B',
			'hero.avgLine': 'TB {dmg} sát thương · {pts} điểm',
			'hero.slotTip': '{games} trận · thắng {pct}% ({w}T-{l}B)',
			'hero.fpTip': 'thắng {pct}% trong {games} trận',
			'hero.warmupNote': 'Tỷ lệ thắng theo số trận đã đấu trong phiên, tính trên mọi phiên trong mùa này.',
			'hero.message': 'Trận {i}',
			'hero.ptsRank': '{score} điểm · {rank}',
			'hero.winRateWindow': 'tỷ lệ thắng {n} trận là {pct}%',
			'hero.fpYou': 'Bạn mở màn',
			'hero.fpThey': 'Đối thủ mở màn',

			/* session tab */
			'sess.none': 'Không có phiên nào trong mùa này.',
			'sess.header': 'Phiên {i}/{n} · {date} {from}–{to}',
			'sess.scoreNote': 'Điểm sau mỗi trận trong phiên · bấm một cột ở bảng Phiên đấu để đổi.',
			'sess.games': 'Số trận',
			'sess.record': 'Thành tích',
			'sess.winRate': 'Tỷ lệ thắng',
			'sess.net': 'Điểm ròng',
			'sess.length': 'Thời lượng',
			'sess.score': 'Điểm',
			'sess.minutes': '{n} phút',
			'sess.gameN': 'Trận {n}',
			'sess.axis': 'trận trong phiên',
			'sess.playedWin': 'THẮNG',
			'sess.playedLoss': 'THUA',
			'sess.result': 'Kết quả',
			'sess.points': 'Điểm',
			'sess.turns': 'Lượt',
			'sess.team': 'Đội hình',

			/* table + detail */
			't.hero': 'Tướng',
			't.games': 'Số trận',
			't.winPct': 'Thắng %',
			't.mvpPct': 'MVP %',
			't.avgDmg': 'ST TB',
			't.avgTaken': 'Chịu TB',
			't.avgHeal': 'Hồi TB',
			't.kills': 'Hạ gục',
			't.slot': 'Vị trí',
			't.cr': 'CR',
			't.sets': 'Bộ',
			't.artifact': 'Artifact',
			'd.win': 'Tỷ lệ thắng',
			'd.mvp': 'MVP',
			'd.avgPts': 'Điểm TB',
			'd.pick': 'Chọn',
			'd.ban': 'Cấm',
			'd.dmg': 'Sát thương',
			'd.taken': 'Sát thương chịu',
			'd.heal': 'Hồi máu',
			'd.respawns': 'Hồi sinh',
			'd.winShort': 'Thắng',
			'd.kills': 'Hạ gục',
			'd.cr': 'CR TB',
			'd.noSets': 'Không có dữ liệu bộ trang bị cho tướng này.',
			'd.noArtifacts': 'Không có dữ liệu Artifact cho tướng này.',
			'd.iconMeta': '{games} trận · {pct}%',
			'hero.firstPick': 'Chọn trước',
			'hero.secondPick': 'Chọn sau',

			/* chips */
			'chip.noSessions': 'Không có phiên',
			'chip.sessions': 'Số phiên',
			'chip.avgLength': 'Độ dài TB',
			'chip.best': 'Hay nhất',
			'chip.toughest': 'Khó nhất',
			'unit.minShort': 'ph',
			'chip.session': 'P{i} · {w}T-{l}B · {pct}% · ròng {net}',

			/* empty state */
			'empty.title': 'Chưa ghi nhận trận xếp hạng nào của người chơi này.',
			'empty.hint': 'Đợi lịch sử đấu tải xong, hoặc mở một người chơi khác.',

			/* analysis tags */
			'tag.initiative.label': 'Chủ động', 'tag.initiative.detail': 'Bạn đi trước trong {v}% số trận (n={n}) — đội bạn thắng cuộc đua tốc độ nhờ thanh năng lượng.',
			'tag.reaction.label': 'Bị động', 'tag.reaction.detail': 'Bạn thường đi sau ({v}% lượt mở màn, n={n}). Bạn chơi trong thế bị động về nhịp.',
			'tag.coinflip.label': 'Tung đồng xu lượt 1', 'tag.coinflip.detail': 'Lượt mở màn hoàn toàn may rủi ({v}% chủ động, n={n}).',
			'tag.secondWind.label': 'Gỡ ở hiệp sau', 'tag.secondWind.detail': 'Bạn thắng {op}% khi đối thủ mở màn, so với {me}% khi bạn mở màn — phản ứng tốt hơn dẫn dắt.',
			'tag.frontRunner.label': 'Kẻ dẫn đầu', 'tag.frontRunner.detail': 'Bạn thắng {me}% khi chọn trước, so với {op}% khi đối thủ chọn trước — dẫn dắt cấm chọn có lợi.',
			'tag.draftAgnostic.label': 'Không phụ thuộc cấm chọn', 'tag.draftAgnostic.detail': 'Chọn trước gần như không đổi tỷ lệ thắng ({me}% so với {op}%).',
			'tag.heroGod.label': '{hero} Thánh', 'tag.heroGod.detail': '{hero}: thắng {pct}% trong {games} trận ({mvp}% MVP). Lựa chọn đáng tin nhất của bạn.',
			'tag.heroTrap.label': 'Bẫy {hero}', 'tag.heroTrap.detail': '{hero}: chỉ {pct}% trong {games} trận. Dùng nhiều mà hiệu quả thấp — nên cất đi.',
			'tag.chameleon.label': 'Tắc kè hoa', 'tag.chameleon.detail': 'Bạn đổi ít nhất 3 tướng trong {v}% số trận liên tiếp (n={n}) — rất khó bị cấm chọn.',
			'tag.oneTrick.label': 'Một bài', 'tag.oneTrick.detail': 'Chỉ {v}% số trận đổi đội hình (n={n}). Bạn ép đội hình và thách đối thủ cản.',
			'tag.blitz.label': 'Vua thần tốc', 'tag.blitz.detail': 'Điểm nhịp {v}/100 — trung bình {turns} lượt (mốc giữa là 15). Bạn thắng nhanh hoặc không thắng.',
			'tag.ironWall.label': 'Tường thành', 'tag.ironWall.detail': 'Điểm nhịp {v}/100 — trung bình {turns} lượt. Bạn nhây tới cùng.',
			'tag.slowStarter.label': 'Khởi động chậm', 'tag.slowStarter.detail': '4 trận đầu mỗi phiên: {open}% so với {overall}% chung. Bạn cần khởi động trước khi vào guồng.',
			'tag.fastStarter.label': 'Vào guồng nhanh', 'tag.fastStarter.detail': '4 trận đầu mỗi phiên: {open}% so với {overall}% chung. Vào trận là sắc ngay.',
			'tag.marathon.label': 'Đường dài', 'tag.marathon.detail': 'Trận thứ 20 trở đi trong phiên: {pct}% (n={n}). Càng đánh lâu càng hay.',
			'tag.primeTime.label': 'Giờ vàng', 'tag.primeTime.detail': 'Thắng {pct}% vào khung {hour}:00 (n={n}).',
			'tag.roughDay.label': 'Ngày xấu {day}', 'tag.roughDay.detail': 'Các trận ngày {day} chỉ đạt {pct}% (n={n}) so với {overall}% chung.',
			'tag.heater.label': 'Đang sung', 'tag.heater.detail': 'Chuỗi hay nhất mùa này: {n} trận thắng liên tiếp.',
			'tag.tilt.label': 'Vòng xoáy thua', 'tag.tilt.detail': 'Chuỗi tệ nhất: {n} trận thua liên tiếp. Nên dừng hẳn sau 3 trận.',
			'tag.economy.label': 'Hiệu suất điểm', 'tag.economy.detail': 'Thắng được +{win}, thua mất {loss}. Ròng {net} cả mùa.',

			/* dates */
			'day.0': 'Chủ nhật', 'day.1': 'Thứ hai', 'day.2': 'Thứ ba', 'day.3': 'Thứ tư', 'day.4': 'Thứ năm', 'day.5': 'Thứ sáu', 'day.6': 'Thứ bảy',
			'month.0': 'thg 1', 'month.1': 'thg 2', 'month.2': 'thg 3', 'month.3': 'thg 4', 'month.4': 'thg 5', 'month.5': 'thg 6',
			'month.6': 'thg 7', 'month.7': 'thg 8', 'month.8': 'thg 9', 'month.9': 'thg 10', 'month.10': 'thg 11', 'month.11': 'thg 12'
		}
	};

	/** Translate `key`, substituting {name} placeholders from `params`. */
	function t(key, params) {
		var table = DICT[LANG] || DICT.en;
		var s = table[key];
		if (s === undefined) s = DICT.en[key];
		if (s === undefined) return key;
		if (!params) return s;
		return s.replace(/\{(\w+)\}/g, function (m, k) { return params[k] == null ? m : params[k]; });
	}

	function setLang(l) {
		if (LANGS.indexOf(l) < 0 || l === LANG) return;
		LANG = l;
		try { localStorage.setItem(STORE, l); } catch (e) {}
		listeners.slice().forEach(function (fn) { try { fn(l); } catch (e) {} });
	}
	function onChange(fn) { listeners.push(fn); }
	function langs() { return LANGS.slice(); }
	function label(l) { return l === 'vi' ? 'VI' : 'EN'; }

	try { var saved = localStorage.getItem(STORE); if (saved && LANGS.indexOf(saved) >= 0) LANG = saved; } catch (e) {}

	return { t: t, setLang: setLang, onChange: onChange, langs: langs, label: label, lang: function () { return LANG; } };
})();
