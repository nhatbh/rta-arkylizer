/*
 * Render layer (isolated world). Builds the profile-dashboard overlay and draws it with Chart.js.
 * Scoped under .e7rta so it can't collide with the host page.
 *
 *   E7Render.mount(rootEl, { onClose })
 *   E7Render.update(data, profile)   // data = { meta, views }, profile = page-extracted player card
 */
(function () {
	'use strict';

	var ROOT = null, TIP = null, OPTS = {};
	var CHARTS = {};
	var pending = [];
	var raf = window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function (f) { return setTimeout(f, 16); };
	var state = { data: null, profile: null, view: null, session: 0, tab: 'heroes', heroOpen: null };
	var COL = {}, EL = {}, RANK_COLORS = {};
	var WD = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

	var $ = function (s) { return ROOT ? ROOT.querySelector(s) : null; };
	var signed = function (n) { return (n > 0 ? '+' : '') + n; };
	var fmtDate = function (t) { return new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }); };
	var fmtTime = function (t) { return new Date(t).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', hour12: false }); };
	var fmtDateTime = function (t) { return new Date(t).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); };
	var cap = function (s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; };
	/** "2357 Victory Points / Top0.4 %" -> "2357 VP · Top 0.4%" */
	function fmtScore(s) {
		if (!s) return '';
		var pts = /([\d,]+)\s*(?:VP|Victory Points)/i.exec(s);
		var top = /Top\s*([\d.]+)/i.exec(s);
		var out = [];
		if (pts) out.push(pts[1] + ' VP');
		if (top) out.push('Top ' + top[1] + '%');
		return out.join(' · ') || String(s).replace(/\s+/g, ' ').trim();
	}
	var elColor = function (e) { return EL[String(e || '').toLowerCase()] || COL.faint; };
	function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
	function clear(node) { if (node) node.textContent = ''; }

	var THEME_KEYS = ['unranked', 'bronze', 'silver', 'gold', 'master', 'challenger', 'champion', 'warlord', 'emperor', 'legend'];
	/** The rank drives the whole card's theme — hue-tinted neutrals, accent, glows and chart lines. */
	function applyTheme(tierKey) {
		for (var i = 0; i < THEME_KEYS.length; i++) ROOT.classList.remove('e7rta--' + THEME_KEYS[i]);
		ROOT.classList.add('e7rta--' + (THEME_KEYS.indexOf(tierKey) >= 0 ? tierKey : 'unranked'));
		// chart colours are read from CSS vars, so re-read them for the new theme
		setupChartDefaults();
	}

	/* ---------- tooltip ---------- */
	function place(ev) {
		var pad = 14, r = TIP.getBoundingClientRect();
		var x = ev.clientX + pad, y = ev.clientY + pad;
		if (x + r.width > window.innerWidth - 8) x = ev.clientX - r.width - pad;
		if (y + r.height > window.innerHeight - 8) y = ev.clientY - r.height - pad;
		TIP.style.left = Math.max(8, x) + 'px';
		TIP.style.top = Math.max(8, y) + 'px';
	}
	function showTip(html, ev) { TIP.innerHTML = html; TIP.hidden = false; place(ev); }
	function hideTip() { TIP.hidden = true; }
	function bindTip(node, fn) {
		node.addEventListener('pointerenter', function (ev) { showTip(fn(), ev); });
		node.addEventListener('pointermove', place);
		node.addEventListener('pointerleave', hideTip);
		node.addEventListener('focus', function () { var r = node.getBoundingClientRect(); showTip(fn(), { clientX: r.left + r.width / 2, clientY: r.top }); });
		node.addEventListener('blur', hideTip);
	}

	/* ---------- chart plumbing ---------- */
	function setupChartDefaults() {
		var cs = getComputedStyle(ROOT);
		COL = {
			win: cs.getPropertyValue('--e7rta-win').trim(), loss: cs.getPropertyValue('--e7rta-loss').trim(),
			accent: cs.getPropertyValue('--e7rta-accent').trim(), ink: cs.getPropertyValue('--e7rta-ink').trim(),
			muted: cs.getPropertyValue('--e7rta-muted').trim(), faint: cs.getPropertyValue('--e7rta-faint').trim(),
			line: cs.getPropertyValue('--e7rta-line').trim(), lineSoft: cs.getPropertyValue('--e7rta-line-soft').trim(),
			panel: cs.getPropertyValue('--e7rta-panel').trim()
		};
		EL = {
			fire: cs.getPropertyValue('--e7rta-fire').trim(), ice: cs.getPropertyValue('--e7rta-ice').trim(),
			earth: cs.getPropertyValue('--e7rta-earth').trim(), light: cs.getPropertyValue('--e7rta-light').trim(),
			dark: cs.getPropertyValue('--e7rta-dark').trim()
		};
		RANK_COLORS = {
			bronze: '#bd7f47', silver: '#c9d3de', gold: '#e0b64f', master: '#3ecf88', challenger: '#4a90e2',
			champion: '#ffdf8a', warlord: '#4ec9c1', emperor: '#e8324f', legend: '#6fd7ff', unranked: '#8a8f98'
		};
		Chart.defaults.color = COL.faint;
		Chart.defaults.borderColor = COL.lineSoft;
		Chart.defaults.font.family = 'ui-sans-serif, system-ui, "Segoe UI", Roboto, sans-serif';
		Chart.defaults.font.size = 11;
		/* Charts render without Chart.js's own tweening — 8 canvases animate at once and the entry
		   motion is handled in CSS instead. */
		Chart.defaults.animation = false;
		Chart.defaults.plugins.legend.display = false;
		Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(16,16,20,0.97)';
		Chart.defaults.plugins.tooltip.borderColor = COL.line;
		Chart.defaults.plugins.tooltip.borderWidth = 1;
		Chart.defaults.plugins.tooltip.padding = 9;
		Chart.defaults.plugins.tooltip.titleColor = COL.ink;
		Chart.defaults.plugins.tooltip.bodyColor = COL.muted;
	}
	function destroyCharts() { pending.length = 0; for (var k in CHARTS) { try { CHARTS[k].destroy(); } catch (e) {} delete CHARTS[k]; } }
	function flush() { var q = pending; pending = []; q.forEach(function (f) { try { f(); } catch (e) {} }); }
	function scheduleFlush() { if (ROOT) void ROOT.offsetHeight; raf(flush); }
	/* Charts are queued and created after layout so canvases have a real size (avoids a 0x0 first paint). */
	function make(id, cfg, after) {
		if (CHARTS[id]) { try { CHARTS[id].destroy(); } catch (e) {} delete CHARTS[id]; }
		pending.push(function () {
			var cv = ROOT && ROOT.querySelector('#' + id);
			if (!cv) return;
			try {
				CHARTS[id] = new Chart(cv.getContext('2d'), cfg);
				if (after) after(CHARTS[id]);
			} catch (e) {}
		});
		return true;
	}
	var axis = function (extra) {
		var o = { grid: { color: COL.lineSoft, drawTicks: false }, border: { display: false }, ticks: { color: COL.faint, font: { size: 10 } } };
		for (var k in (extra || {})) o[k] = extra[k];
		return o;
	};

	/* ---------- banner + rail ---------- */
	function renderBanner() {
		var m = state.data.meta, p = state.profile || {};
		var v = state.view;
		var tierKey = E7Aggregate.rankKey(p.tier || m.latestGrade || '');
		var tierName = p.tier || (m.latestGrade ? cap(m.latestGrade) : 'Unranked');

		var emblem = $('#e7rta-emblem');
		emblem.src = p.emblem || E7Aggregate.emblemUrl(tierKey);
		emblem.alt = tierName + ' emblem';

		var avatar = $('#e7rta-avatar');
		if (p.avatar) { avatar.src = p.avatar; avatar.hidden = false; } else { avatar.hidden = true; }

		$('#e7rta-name').textContent = p.name || (m.nick ? 'Player ' + m.nick : 'Unknown player');
		$('#e7rta-meta').textContent = [p.server, p.clan].filter(Boolean).join(' · ') || (m.world || '');

		applyTheme(tierKey);
		$('#e7rta-tiername').textContent = tierName;
		$('#e7rta-points').textContent = p.score ? fmtScore(p.score) : (v ? v.summary.lastScore + ' pts' : '');
		$('#e7rta-identity').textContent = [p.name || (m.nick ? 'Player ' + m.nick : ''), m.world, m.battleCount + ' games captured'].filter(Boolean).join(' · ');
	}

	function renderSummary() {
		var v = state.view, s = v.summary, host = $('#e7rta-summary');
		clear(host);
		var rows = [
			['Record', s.wins + '–' + s.losses, s.winRate >= 50 ? 'pos' : 'neg'],
			['Win rate', s.winRate + '%', ''],
			['Net points', signed(s.netDelta), s.netDelta >= 0 ? 'pos' : 'neg'],
			['Current score', String(s.lastScore), ''],
			['Peak / low', s.peak + ' / ' + s.trough, ''],
			['Sessions', String(s.sessions), '']
		];
		rows.forEach(function (r) {
			var dt = el('dt', null, r[0]);
			var dd = el('dd', r[2] ? 'e7rta-' + r[2] : null, r[1]);
			host.appendChild(dt); host.appendChild(dd);
		});
	}

	function renderTags() {
		var host = $('#e7rta-tags');
		clear(host);
		state.view.tags.forEach(function (t) {
			var b = el('button', 'e7rta-tag e7rta-tag--' + t.tone, t.label);
			b.type = 'button';
			b.setAttribute('aria-label', t.label + ': ' + t.detail);
			bindTip(b, function () { return '<b>' + t.label + '</b><br>' + t.detail; });
			host.appendChild(b);
		});
	}

	/* ---------- recent form + knobs ---------- */
	function renderRecent() {
		var v = state.view, r = v.recent;
		$('#e7rta-recent-sub').textContent = 'last ' + r.n + ' games';
		var strip = $('#e7rta-formstrip');
		clear(strip);
		r.form.forEach(function (w, i) {
			var d = el('span', 'e7rta-pip ' + (w ? 'e7rta-pip--win' : 'e7rta-pip--loss'));
			d.title = 'Game ' + (i + 1) + ': ' + (w ? 'win' : 'loss');
			strip.appendChild(d);
		});
		var boxHost = $('#e7rta-recent-boxes');
		clear(boxHost);
		var boxes = [
			['Win rate', r.winRate + '%'],
			['Net points', signed(r.net)],
			['Avg / game', signed(r.avgDelta)],
			['Streak', (v.streaks.current.win ? 'W' : 'L') + v.streaks.current.length]
		];
		boxes.forEach(function (b) {
			var box = el('div', 'e7rta-box');
			box.appendChild(el('span', 'e7rta-box-v', b[1]));
			box.appendChild(el('span', 'e7rta-box-k', b[0]));
			boxHost.appendChild(box);
		});
	}

	function renderKnobs() {
		var pl = state.view.playstyle, host = $('#e7rta-knobs');
		clear(host);
		var knobs = [
			{ title: 'Lineup', left: 'Forcer', right: 'Flexible', value: pl.flex.value, note: pl.flex.n ? pl.flex.value + '% fresh lineups (n=' + pl.flex.n + ')' : 'not enough games' },
			{ title: 'Match length', left: 'Siege', right: 'Blitz', value: pl.tempo.value, note: pl.tempo.n ? 'avg ' + pl.tempo.avgTurns + ' turns · 15 is the midpoint' : 'no turn data' },
			{ title: 'Opening turn', left: 'Reaction', right: 'Initiative', value: pl.initiative.value, note: pl.initiative.n ? pl.initiative.value + '% opening turns held (n=' + pl.initiative.n + ')' : 'no energy-gauge data' }
		];
		knobs.forEach(function (k) {
			var wrap = el('div', 'e7rta-knob');
			var head = el('div', 'e7rta-knob-head');
			head.appendChild(el('span', 'e7rta-knob-title', k.title));
			head.appendChild(el('span', 'e7rta-knob-note', k.note));
			wrap.appendChild(head);
			var scale = el('div', 'e7rta-knob-scale');
			scale.appendChild(el('span', 'e7rta-knob-end', k.left));
			var track = el('div', 'e7rta-knob-track');
			var mark = el('i');
			mark.style.left = Math.max(0, Math.min(100, k.value)) + '%';
			track.appendChild(mark);
			scale.appendChild(track);
			scale.appendChild(el('span', 'e7rta-knob-end', k.right));
			wrap.appendChild(scale);
			host.appendChild(wrap);
		});
	}

	/* ---------- charts ---------- */
	function renderRankPoints() {
		var rec = state.view.series.slice(-40);
		$('#e7rta-rankpoints-sub').textContent = 'last ' + rec.length;
		make('e7rta-c-rankpts', {
			type: 'bar',
			data: {
				labels: rec.map(function (_, i) { return i + 1; }),
				datasets: [{ data: rec.map(function (r) { return r.delta; }), backgroundColor: rec.map(function (r) { return r.win ? COL.win : COL.loss; }), borderRadius: 3, barPercentage: 0.72, categoryPercentage: 0.9 }]
			},
			options: {
				responsive: true, maintainAspectRatio: false,
				plugins: { tooltip: { callbacks: { title: function (c) { return 'Match ' + c[0].label; }, label: function (c) { return signed(c.raw) + ' points'; } } } },
				scales: { x: axis({ display: false }), y: axis({ ticks: { color: COL.faint, font: { size: 10 }, callback: function (v) { return v > 0 ? '+' + v : v; } } }) }
			}
		});
	}

	function renderJourney() {
		var rec = state.view.series;
		var colors = rec.map(function (r) { return RANK_COLORS[r.rank] || RANK_COLORS.unranked; });
		var win = Math.max(6, Math.min(20, Math.round(rec.length / 5)));
		make('e7rta-c-journey', {
			type: 'line',
			data: {
				labels: rec.map(function (_, i) { return i + 1; }),
				datasets: [
					{
						data: rec.map(function (r) { return r.score; }),
						borderWidth: 2, pointRadius: 0, tension: 0.28, fill: true,
						borderColor: COL.accent, yAxisID: 'y',
						backgroundColor: function (c) {
							var a = c.chart.chartArea; if (!a) return 'transparent';
							var g = c.chart.ctx.createLinearGradient(0, a.top, 0, a.bottom);
							g.addColorStop(0, 'rgba(224,182,79,0.28)'); g.addColorStop(1, 'rgba(224,182,79,0)');
							return g;
						},
						segment: { borderColor: function (c) { return colors[c.p1DataIndex] || COL.accent; } }
					},
					/* rolling win rate — deliberately quiet: dashed, unfilled, on its own 0-100 axis */
					{
						data: rollingAligned(rec, win),
						borderColor: COL.faint, borderWidth: 1.2, borderDash: [4, 4],
						pointRadius: 0, tension: 0.3, fill: false, yAxisID: 'y1'
					}
				]
			},
			options: {
				responsive: true, maintainAspectRatio: false,
				interaction: { intersect: false, mode: 'index' },
				plugins: {
					tooltip: {
						callbacks: {
							title: function (c) { return 'Match ' + c[0].label; },
							label: function (c) {
								if (c.datasetIndex === 1) return c.raw == null ? undefined : win + '-game win rate ' + c.raw + '%';
								var r = rec[c.dataIndex];
								return r.score + ' pts · ' + cap(r.rank || 'unranked');
							}
						}
					}
				},
				scales: {
					x: axis({ display: false }),
					y: axis({ ticks: { color: COL.faint, font: { size: 10 } } }),
					y1: axis({ position: 'right', min: 0, max: 100, grid: { display: false }, ticks: { color: COL.faint, font: { size: 10 }, callback: function (v) { return v + '%'; } } })
				}
			}
		});
	}
	function rolling(records, win) {
		var out = [];
		for (var i = win - 1; i < records.length; i++) { var w = 0; for (var j = i - win + 1; j <= i; j++) if (records[j].win) w++; out.push({ i: i, v: (100 * w) / win }); }
		return out;
	}
	function renderSessions() {
		var S = state.view.sessions;
		var stats = $('#e7rta-session-stats');
		clear(stats);
		if (!S.length) { stats.appendChild(el('span', 'e7rta-chip', 'No sessions')); return; }
		var best = S.slice().sort(function (a, b) { return b.netDelta - a.netDelta; })[0];
		var pool = S.filter(function (s) { return s.battles >= 8; });
		var worst = (pool.length ? pool : S).slice().sort(function (a, b) { return a.winRate - b.winRate; })[0];
		[['Sessions', String(state.view.summary.sessions)], ['Avg length', state.view.summary.avgSessionGames + ' games'], ['Best', 'S' + best.i + ' ' + signed(best.netDelta)], ['Toughest', 'S' + worst.i + ' ' + worst.winRate + '%']]
			.forEach(function (c) { var s = el('span', 'e7rta-chip'); s.appendChild(el('b', null, c[1])); var t = document.createTextNode(' ' + c[0]); s.appendChild(t); stats.appendChild(s); });
		var sel = state.view.sessions[state.session];
		var nav = $('#e7rta-session-nav');
		clear(nav);
		if (sel) {
			nav.appendChild(el('span', 'e7rta-chip e7rta-chip--' + (sel.winRate >= 50 ? 'win' : 'loss'), 'S' + sel.i + ' · ' + sel.wins + 'W-' + sel.losses + 'L · ' + sel.winRate + '% · net ' + signed(sel.netDelta)));
			nav.appendChild(el('span', 'e7rta-chip', fmtDate(sel.start) + ' ' + fmtTime(sel.start) + '–' + fmtTime(sel.end) + ' · ' + sel.durationMin + 'm'));
		}
		var bar = make('e7rta-c-sessions', {
			type: 'bar',
			data: {
				labels: S.map(function (s) { return 'S' + s.i; }),
				datasets: [
					{ data: S.map(function (s) { return s.winRate; }), backgroundColor: S.map(function (s, i) { return i === state.session ? COL.accent : (s.winRate >= 50 ? COL.win : COL.loss); }), borderRadius: 4, barPercentage: 0.55, yAxisID: 'y' },
					{ type: 'line', data: S.map(function (s) { return s.netDelta; }), borderColor: COL.muted, borderWidth: 1.5, pointRadius: 0, tension: 0.3, yAxisID: 'y1' }
				]
			},
			options: {
				responsive: true, maintainAspectRatio: false,
				plugins: { tooltip: { callbacks: {
					title: function (c) { var s = S[c[0].dataIndex]; return 'Session ' + s.i + ' · ' + fmtDate(s.start) + ' ' + fmtTime(s.start); },
					label: function (c) { var s = S[c.dataIndex]; return [s.wins + 'W-' + s.losses + 'L (' + s.winRate + '%)', 'net ' + signed(s.netDelta), s.battles + ' games · ' + s.durationMin + 'm']; }
				} } },
				onClick: function (evt, els) {
					if (els && els.length) {
						var idx = els[0].index;
						// defer: rebuilding the chart from inside its own click handler tears down the
						// plugin registry while Chart.js is still dispatching the event
						setTimeout(function () {
							state.session = idx;
							renderSessions();
							if (state.tab === 'sessions') renderTab();
							scheduleFlush();
						}, 0);
					}
				},
				scales: {
					x: axis({ grid: { display: false } }),
					y: axis({ min: 0, max: 100, ticks: { color: COL.faint, font: { size: 10 }, callback: function (v) { return v + '%'; } } }),
					y1: axis({ position: 'right', grid: { display: false }, ticks: { color: COL.faint, font: { size: 10 } } })
				}
			}
		});
		return bar;
	}

	/* ---------- bottom tabs ---------- */
	function buildTablist() {
		var host = $('#e7rta-tablist');
		clear(host);
		[['heroes', 'Heroes'], ['sessions', 'Sessions']].forEach(function (t) {
			var b = el('button', 'e7rta-tab', t[1]);
			b.type = 'button'; b.setAttribute('role', 'tab');
			b.setAttribute('aria-selected', String(state.tab === t[0]));
			b.addEventListener('click', function () { state.tab = t[0]; buildTablist(); renderTab(); scheduleFlush(); });
			host.appendChild(b);
		});
	}
	function renderTab() {
		var host = $('#e7rta-panel');
		clear(host);
		if (state.tab === 'sessions') sessionsTab(host);
		else heroesTab(host);
	}

	function chartBlock(host, id, cls) {
		var wrap = el('div', 'e7rta-canvaswrap ' + (cls || ''));
		var cv = el('canvas'); cv.id = id;
		wrap.appendChild(cv); host.appendChild(wrap);
		return wrap;
	}

	var IMGS = {};
	var portraitsRegistered = false;
	function registerPortraitPlugin() {
		if (portraitsRegistered) return;
		portraitsRegistered = true;
		Chart.register({
			id: 'e7rtaPortraits',
			afterDatasetsDraw: function (chart) {
				var codes = chart.$e7Portraits;
				if (!codes || !chart.chartArea) return;
				var meta = chart.getDatasetMeta(0);
				if (!meta || !meta.data) return;
				var ctx = chart.ctx;
				var top = chart.chartArea.bottom + 7;
				var size = 28;
				var drawn = 0;
				meta.data.forEach(function (bar, i) {
					var x = bar.x - size / 2;
					var img = IMGS[codes[i]];
					ctx.save();
					ctx.beginPath();
					if (ctx.roundRect) ctx.roundRect(x, top, size, size, 6); else ctx.rect(x, top, size, size);
					ctx.clip();
					/* the CDN sends no CORS headers, so drawing these taints the canvas — fine for display */
					if (img && img.complete && img.naturalWidth) { ctx.drawImage(img, x, top, size, size); drawn++; }
					else { ctx.fillStyle = 'rgba(255,255,255,.07)'; ctx.fillRect(x, top, size, size); }
					ctx.restore();
					ctx.strokeStyle = 'rgba(255,255,255,.14)';
					ctx.lineWidth = 1;
					ctx.beginPath();
					if (ctx.roundRect) ctx.roundRect(x, top, size, size, 6); else ctx.rect(x, top, size, size);
					ctx.stroke();
				});
				chart.$e7PortraitsDrawn = drawn;
			}
		});
	}
	function preloadPortraits(heroes, done) {
		var cache = {}, left = heroes.length;
		if (!left) { done(cache); return; }
		heroes.forEach(function (h) {
			var img = new Image();
			img.onload = img.onerror = function () { if (--left <= 0) done(cache); };
			img.src = h.portrait;
			cache[h.code] = img;
		});
	}
	function fmtInt(n) { return Math.round(Number(n) || 0).toLocaleString(); }
	function ordinal(n) { return n === 1 ? 'st' : n === 2 ? 'nd' : n === 3 ? 'rd' : 'th'; }
	function icon(src, label, cls) {
		var img = el('img', cls);
		img.src = src;
		img.alt = label || '';
		img.loading = 'lazy';
		img.addEventListener('error', function () {
			var fb = el('span', 'e7rta-icon-fb', String(label || '?').slice(0, 2).toUpperCase());
			if (img.parentNode) img.parentNode.replaceChild(fb, img);
		});
		return img;
	}
	function iconStrip(list, max) {
		var wrap = el('div', 'e7rta-iconstrip');
		if (!list || !list.length) { wrap.appendChild(el('span', 'e7rta-sub', '—')); return wrap; }
		list.slice(0, max).forEach(function (x) {
			var im = icon(x.icon, x.name, 'e7rta-iconstrip-img');
			bindTip(im, function () { return '<b>' + x.name + '</b><br>' + x.games + ' games · ' + x.pct + '%'; });
			wrap.appendChild(im);
		});
		return wrap;
	}
	function tile(k, v) {
		var d = el('div', 'e7rta-hd-tile');
		d.appendChild(el('span', 'e7rta-hd-tilev', String(v)));
		d.appendChild(el('span', 'e7rta-hd-tilek', k));
		return d;
	}
	function iconList(list, emptyMsg) {
		var box = el('div', 'e7rta-hd-icons');
		if (!list.length) { box.appendChild(el('span', 'e7rta-sub', emptyMsg)); return box; }
		list.slice(0, 10).forEach(function (x) {
			var row = el('div', 'e7rta-hd-icon');
			row.appendChild(icon(x.icon, x.name, 'e7rta-hd-iconimg'));
			var txt = el('div', 'e7rta-hd-icontext');
			txt.appendChild(el('span', 'e7rta-hd-iconname', x.name));
			txt.appendChild(el('span', 'e7rta-hd-iconmeta', x.games + ' games · ' + x.pct + '%'));
			row.appendChild(txt);
			box.appendChild(row);
		});
		return box;
	}
	function heroDetail(h) {
		var d = el('div', 'e7rta-hdetail');

		// left — compact stat cards, sets and artifacts
		var left = el('div', 'e7rta-hd-left');
		var head = el('div', 'e7rta-hd-head');
		head.appendChild(icon(h.portrait, h.name, 'e7rta-hd-portrait'));
		var who = el('div', 'e7rta-hd-who');
		who.appendChild(el('strong', 'e7rta-hd-name', h.name));
		who.appendChild(el('span', 'e7rta-hd-role', [(h.element || ''), h.role || ''].filter(Boolean).join(' · ')));
		head.appendChild(who);
		left.appendChild(head);

		var t1 = el('div', 'e7rta-hd-tiles e7rta-hd-tiles--sm');
		[['Games', h.games], ['Win', h.winRate + '%'], ['MVP', h.mvpRate + '%'], ['Avg pts', signed(h.avgDelta)], ['Pick', h.pickRate + '%'], ['Ban', h.banRate + '%']].forEach(function (x) { t1.appendChild(tile(x[0], x[1])); });
		left.appendChild(t1);

		var t2 = el('div', 'e7rta-hd-tiles e7rta-hd-tiles--sm');
		[['Damage', fmtInt(h.avgDamage)], ['Taken', fmtInt(h.avgDamageTaken)], ['Healing', fmtInt(h.avgRecovery)], ['Kills', h.avgKills], ['Respawns', h.avgRespawn], ['Avg CR', h.avgCR == null ? '—' : h.avgCR]].forEach(function (x) { t2.appendChild(tile(x[0], x[1])); });
		left.appendChild(t2);

		var setBlock = el('div', 'e7rta-hd-block');
		setBlock.appendChild(el('h5', 'e7rta-hd-h5', 'Item sets'));
		setBlock.appendChild(iconList(h.setsList, 'No set data for this hero.'));
		left.appendChild(setBlock);

		var artBlock = el('div', 'e7rta-hd-block');
		artBlock.appendChild(el('h5', 'e7rta-hd-h5', 'Artifacts'));
		artBlock.appendChild(iconList(h.artifactsList, 'No artifact data for this hero.'));
		left.appendChild(artBlock);
		d.appendChild(left);

		// right — this hero's draft position and first/second-pick record, as charts
		var right = el('div', 'e7rta-hd-right');
		right.appendChild(el('h5', 'e7rta-hd-h5', 'Pick position'));
		var sw = el('div', 'e7rta-canvaswrap e7rta-canvaswrap--hd');
		var sc = el('canvas'); sc.id = 'e7rta-c-hd-slots';
		sw.appendChild(sc); right.appendChild(sw);
		right.appendChild(el('h5', 'e7rta-hd-h5', 'First vs second pick'));
		var fw = el('div', 'e7rta-canvaswrap e7rta-canvaswrap--hd-sm');
		var fc = el('canvas'); fc.id = 'e7rta-c-hd-fp';
		fw.appendChild(fc); right.appendChild(fw);
		d.appendChild(right);

		return d;
	}

	function heroesTab(host) {
		var v = state.view;
		var heroes = v.heroes.filter(function (h) { return h.games > 0; });

		// row 1 — stacked win/loss columns (expands to fit, scrolls only when it overflows)
		var s1 = el('div', 'e7rta-hsection');
		s1.appendChild(el('h4', 'e7rta-h4', 'Heroes by record'));
		var scroll = el('div', 'e7rta-scroll');
		var inner = el('div', 'e7rta-scroll-inner');
		inner.style.minWidth = (heroes.length * 34) + 'px';
		inner.style.height = '296px';
		var cv1 = el('canvas'); cv1.id = 'e7rta-c-heroes';
		inner.appendChild(cv1); scroll.appendChild(inner); s1.appendChild(scroll);
		host.appendChild(s1);

		// row 2 — ledger table with an expanding per-hero panel
		var s3 = el('div', 'e7rta-hsection');
		s3.appendChild(el('h4', 'e7rta-h4', 'Hero ledger'));
		var tableHost = el('div');
		tableHost.id = 'e7rta-hero-table';
		s3.appendChild(tableHost);
		host.appendChild(s3);
		buildHeroTable(tableHost, heroes);

		// charts (images first, so the portrait plugin can draw them)
		registerPortraitPlugin();
		preloadPortraits(heroes, function (cache) {
			IMGS = cache;
			var codes = heroes.map(function (h) { return h.code; });
			make('e7rta-c-heroes', heroChartCfg(heroes), function (chart) { chart.$e7Portraits = codes; chart.update('none'); });
			scheduleFlush();
		});
	}

	/** Per-hero pick position: bar LENGTH is the number of games drafted in that slot. */
	function hdSlotsCfg(h) {
		return {
			type: 'bar',
			data: {
				labels: h.slots.map(function (s) { return s.slot + ordinal(s.slot); }),
				datasets: [
					{ label: 'Won', data: h.slots.map(function (s) { return s.wins; }), backgroundColor: COL.win, stack: 's', borderRadius: 3 },
					{ label: 'Lost', data: h.slots.map(function (s) { return s.losses; }), backgroundColor: COL.loss, stack: 's', borderRadius: 3 }
				]
			},
			options: {
				indexAxis: 'y',
				responsive: true, maintainAspectRatio: false,
				plugins: {
					tooltip: {
						/* nearest + intersect resolves one segment, so this tooltip was never duplicated —
						   do NOT switch to index mode here: on a horizontal chart it resolves the index
						   from x, which pins the tooltip to a single slot. */
						callbacks: {
							label: function (c) {
								var s = h.slots[c.dataIndex];
								return s.games + ' games · ' + s.winRate + '% win (' + s.wins + 'W-' + s.losses + 'L)';
							}
						}
					}
				},
				scales: {
					x: axis({ stacked: true, ticks: { color: COL.faint, font: { size: 10 }, precision: 0 }, title: { display: true, text: 'games drafted', color: COL.faint, font: { size: 10 } } }),
					y: axis({ stacked: true, grid: { display: false } })
				}
			}
		};
	}
	function hdFpCfg(h) {
		return {
			type: 'bar',
			data: { labels: ['First pick', 'Second pick'], datasets: [{ data: [h.firstPickWinRate, h.secondPickWinRate], backgroundColor: [COL.accent, COL.faint], borderRadius: 4, barPercentage: 0.6 }] },
			options: {
				indexAxis: 'y',
				responsive: true, maintainAspectRatio: false,
				plugins: {
					tooltip: {
						callbacks: {
							label: function (c) {
								var g = c.dataIndex === 0 ? h.firstPickGames : h.secondPickGames;
								return c.raw + '% win over ' + g + ' games';
							}
						}
					}
				},
				scales: { x: axis({ min: 0, max: 100, ticks: { color: COL.faint, font: { size: 10 }, callback: function (x) { return x + '%'; } } }), y: axis({ grid: { display: false } }) }
			}
		};
	}


	function heroChartCfg(heroes) {
		return {
			type: 'bar',
			data: {
				labels: heroes.map(function (h) { return h.name; }),
				datasets: [
					{ label: 'Wins', data: heroes.map(function (h) { return h.wins; }), backgroundColor: COL.win, stack: 's', borderRadius: 3, barPercentage: 0.72, categoryPercentage: 0.86 },
					{ label: 'Losses', data: heroes.map(function (h) { return h.games - h.wins; }), backgroundColor: COL.loss, stack: 's', borderRadius: 3, barPercentage: 0.72, categoryPercentage: 0.86 }
				]
			},
			options: {
				responsive: true, maintainAspectRatio: false,
				layout: { padding: { bottom: 40 } },
				interaction: { mode: 'index', intersect: false },
				plugins: {
					tooltip: {
						/* one entry only: Wins and Losses are two halves of one bar, so printing the
						   record once per dataset shows the exact same three lines twice */
						filter: function (item) { return item.datasetIndex === 0; },
						callbacks: {
							title: function (c) { return heroes[c[0].dataIndex].name; },
							label: function (c) {
								var h = heroes[c.dataIndex];
								var lines = [h.games + ' games · ' + h.winRate + '% win', h.wins + 'W-' + (h.games - h.wins) + 'L'];
								if (h.avgDamage != null) lines.push('avg ' + fmtInt(h.avgDamage) + ' dmg · ' + signed(h.avgDelta) + ' pts');
								return lines;
							}
						}
					}
				},
				scales: {
					x: axis({ stacked: true, grid: { display: false }, ticks: { display: false } }),
					y: axis({ stacked: true, ticks: { color: COL.faint, font: { size: 10 }, precision: 0 } })
				}
			}
		};
	}
	function buildHeroTable(host, heroes) {
		clear(host);
		var wrap = el('div', 'e7rta-tablewrap');
		var tbl = el('table', 'e7rta-ledger');
		var thead = el('thead'); var tr = el('tr');
		['Hero', 'Games', 'Win %', 'MVP %', 'Avg dmg', 'Avg taken', 'Avg heal', 'Kills', 'Slot', 'CR', 'Sets', 'Artifact'].forEach(function (h) { tr.appendChild(el('th', null, h)); });
		thead.appendChild(tr); tbl.appendChild(thead);
		var tb = el('tbody');
		heroes.forEach(function (h) {
			var row = el('tr', 'e7rta-hrow');
			row.tabIndex = 0;
			row.setAttribute('role', 'button');
			row.setAttribute('aria-expanded', String(state.heroOpen === h.code));
			var td0 = el('td', 'e7rta-hero-cell');
			td0.appendChild(icon(h.portrait, h.name, 'e7rta-portrait'));
			td0.appendChild(document.createTextNode(h.name));
			row.appendChild(td0);
			var best = h.slots.slice().sort(function (a, b) { return b.games - a.games; })[0];
			[h.games, h.winRate + '%', h.mvpRate + '%', fmtInt(h.avgDamage), fmtInt(h.avgDamageTaken), fmtInt(h.avgRecovery), h.avgKills, best && best.games ? best.slot + ordinal(best.slot) + ' · ' + pctOf(best.games, h.games) + '%' : '—', h.avgCR == null ? '—' : String(h.avgCR)].forEach(function (t) { row.appendChild(el('td', null, String(t))); });
			var setCell = el('td', 'e7rta-iconcell');
			setCell.appendChild(iconStrip(h.setsList, 3));
			row.appendChild(setCell);
			var artCell = el('td', 'e7rta-iconcell');
			artCell.appendChild(iconStrip(h.artifactsList, 2));
			row.appendChild(artCell);
			var toggle = (function (code) { return function () { state.heroOpen = state.heroOpen === code ? null : code; buildHeroTable(host, heroes); }; })(h.code);
			row.addEventListener('click', toggle);
			row.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
			tb.appendChild(row);
			if (state.heroOpen === h.code) {
				var dr = el('tr', 'e7rta-hdetailrow');
				var dc = el('td'); dc.colSpan = 12;
				dc.appendChild(heroDetail(h));
				dr.appendChild(dc); tb.appendChild(dr);
			}
		});
		tbl.appendChild(tb); wrap.appendChild(tbl); host.appendChild(wrap);
		if (state.heroOpen) {
			var open = null;
			for (var i = 0; i < heroes.length; i++) if (heroes[i].code === state.heroOpen) { open = heroes[i]; break; }
			if (open) {
				make('e7rta-c-hd-slots', hdSlotsCfg(open));
				make('e7rta-c-hd-fp', hdFpCfg(open));
				scheduleFlush();
			}
		}
	}
	function pctOf(w, n) { return n ? Math.round((100 * w) / n) : 0; }


	/** Rolling win-rate series aligned to the match index (leading nulls while the window fills). */
	function rollingAligned(records, win) {
		var out = [], count = 0;
		for (var i = 0; i < records.length; i++) {
			if (records[i].win) count++;
			if (i >= win && records[i - win].win) count--;
			out.push(i >= win - 1 ? Math.round((1000 * count) / win) / 10 : null);
		}
		return out;
	}

	/** The selected session: journey and stats, plus the warm-up / fatigue curve. */
	function sessionsTab(host) {
		var v = state.view;
		var S = v.sessions;
		var sel = S[state.session];
		if (!sel) { host.appendChild(el('p', 'e7rta-sub', 'No sessions in this view.')); return; }

		var s1 = el('div', 'e7rta-hsection');
		s1.appendChild(el('h4', 'e7rta-h4', 'Session ' + sel.i + ' of ' + S.length + ' · ' + fmtDate(sel.start) + ' ' + fmtTime(sel.start) + '–' + fmtTime(sel.end)));
		var tiles = el('div', 'e7rta-sess-tiles');
		[['Games', sel.battles], ['Record', sel.wins + 'W-' + sel.losses + 'L'], ['Win rate', sel.winRate + '%'], ['Net points', signed(sel.netDelta)], ['Length', sel.durationMin + ' min'], ['Score', sel.startScore + ' → ' + sel.endScore]]
			.forEach(function (x) { tiles.appendChild(tile(x[0], x[1])); });
		s1.appendChild(tiles);
		var cw = el('div', 'e7rta-canvaswrap e7rta-canvaswrap--sess');
		var cv = el('canvas'); cv.id = 'e7rta-c-sess-journey';
		cw.appendChild(cv); s1.appendChild(cw);
		s1.appendChild(el('p', 'e7rta-sub', 'Score after each game in this session · click a bar in the Sessions panel to switch.'));
		host.appendChild(s1);

		var s2 = el('div', 'e7rta-hsection');
		s2.appendChild(el('h4', 'e7rta-h4', 'Game by game'));
		var strip = el('div', 'e7rta-strip');
		sel.games.forEach(function (g, i) {
			var cell = el('div', 'e7rta-cell ' + (g.win ? 'e7rta-cell--win' : 'e7rta-cell--loss'));
			cell.setAttribute('role', 'listitem');
			cell.innerHTML = '<span class="e7rta-cell-pts" aria-hidden="true">' + signed(g.delta) + '</span><span class="e7rta-cell-n" aria-hidden="true">' + (i + 1) + '</span><span class="e7rta-sr">Game ' + (i + 1) + ': ' + (g.win ? 'win' : 'loss') + ', ' + signed(g.delta) + ' points</span>';
			bindTip(cell, (function (gg, ii) {
				return function () {
					return '<b>Game ' + (ii + 1) + '</b> ' + fmtTime(gg.t) + '<dl><dt>Result</dt><dd>' + (gg.win ? 'WIN' : 'LOSS') + '</dd><dt>Points</dt><dd>' + signed(gg.delta) + '</dd><dt>Turns</dt><dd>' + (gg.turns == null ? '—' : gg.turns) + '</dd><dt>Team</dt><dd>' + (gg.played.join(', ') || '—') + '</dd></dl>';
				};
			})(g, i));
			strip.appendChild(cell);
		});
		s2.appendChild(strip);
		host.appendChild(s2);

		var s3 = el('div', 'e7rta-hsection');
		s3.appendChild(el('h4', 'e7rta-h4', 'Heroes used this session'));
		var hscroll = el('div', 'e7rta-scroll');
		var hinner = el('div', 'e7rta-scroll-inner');
		hinner.style.minWidth = (sel.heroes.length * 34) + 'px';
		hinner.style.height = '240px';
		var hcv = el('canvas'); hcv.id = 'e7rta-c-sess-heroes';
		hinner.appendChild(hcv); hscroll.appendChild(hinner); s3.appendChild(hscroll);
		s3.appendChild(el('p', 'e7rta-sub', sel.heroes.length + ' distinct heroes across ' + sel.battles + ' games this session — hover a bar for the record.'));
		host.appendChild(s3);

		var s4 = el('div', 'e7rta-hsection');
		s4.appendChild(el('h4', 'e7rta-h4', 'Warm-up & fatigue'));
		var ww = el('div', 'e7rta-canvaswrap e7rta-canvaswrap--warmup');
		var wc = el('canvas'); wc.id = 'e7rta-c-warmup';
		ww.appendChild(wc); s4.appendChild(ww);
		s4.appendChild(el('p', 'e7rta-sub', 'Win rate by how many games into a session you are, across every session in this view.'));
		host.appendChild(s4);

		make('e7rta-c-sess-journey', sessJourneyCfg(sel));
		make('e7rta-c-warmup', warmupChartCfg(v.byBucket));
		registerPortraitPlugin();
		preloadPortraits(sel.heroes, function (cache) {
			IMGS = cache;
			var codes = sel.heroes.map(function (h) { return h.code; });
			make('e7rta-c-sess-heroes', heroChartCfg(sel.heroes), function (chart) { chart.$e7Portraits = codes; chart.update('none'); });
			scheduleFlush();
		});
	}

	function sessJourneyCfg(s) {
		return {
			type: 'line',
			data: {
				labels: s.games.map(function (_, i) { return i + 1; }),
				datasets: [{
					data: s.games.map(function (g) { return g.score; }),
					borderColor: COL.accent, borderWidth: 2, pointRadius: 3.5, tension: 0.25, fill: false,
					pointBackgroundColor: s.games.map(function (g) { return g.win ? COL.win : COL.loss; }),
					pointBorderColor: s.games.map(function (g) { return g.win ? COL.win : COL.loss; })
				}]
			},
			options: {
				responsive: true, maintainAspectRatio: false,
				plugins: {
					tooltip: {
						callbacks: {
							title: function (c) { return 'Game ' + c[0].label + ' · ' + fmtTime(s.games[c.dataIndex].t); },
							label: function (c) {
								var g = s.games[c.dataIndex];
								return [(g.win ? 'WIN' : 'LOSS') + ' ' + signed(g.delta), 'score ' + g.score, (g.turns == null ? '—' : g.turns) + ' turns'];
							}
						}
					}
				},
				scales: {
					x: axis({ grid: { display: false }, title: { display: true, text: 'game in session', color: COL.faint, font: { size: 10 } } }),
					y: axis({ ticks: { color: COL.faint, font: { size: 10 } } })
				}
			}
		};
	}
	function warmupChartCfg(byBucket) {
		return {
			type: 'bar',
			data: {
				labels: byBucket.map(function (b) { return b.label; }),
				datasets: [{ data: byBucket.map(function (b) { return b.winRate; }), backgroundColor: byBucket.map(function (b) { return b.winRate >= 50 ? COL.win : COL.loss; }), borderRadius: 4, barPercentage: 0.7 }]
			},
			options: {
				responsive: true, maintainAspectRatio: false,
				plugins: {
					tooltip: {
						callbacks: {
							label: function (c) { var b = byBucket[c.dataIndex]; return [b.winRate + '% win rate', 'n=' + b.battles + ' · net ' + signed(b.netDelta)]; }
						}
					}
				},
				scales: { x: axis({ grid: { display: false } }), y: axis({ min: 0, max: 100, ticks: { color: COL.faint, font: { size: 10 }, callback: function (x) { return x + '%'; } } }) }
			}
		};
	}

	/* ---------- season filter ---------- */
	function renderSeasonFilter() {
		var host = $('#e7rta-season');
		clear(host);
		state.data.views.forEach(function (v) {
			var b = el('button', null, v.label);
			b.type = 'button';
			b.setAttribute('aria-pressed', String(state.view.key === v.key));
			b.addEventListener('click', function () {
				state.view = v; state.session = v.sessions.length ? v.sessions.length - 1 : 0;
				Array.prototype.forEach.call(host.querySelectorAll('button'), function (x) { x.setAttribute('aria-pressed', 'false'); });
				b.setAttribute('aria-pressed', 'true');
				render();
			});
			host.appendChild(b);
		});
	}

	/* ---------- orchestration ---------- */
	function setEmpty(on) {
		var main = $('.e7rta-main'), tabs = $('.e7rta-tabs'), emp = $('#e7rta-empty');
		if (main) main.hidden = on;
		if (tabs) tabs.hidden = on;
		if (emp) emp.hidden = !on;
		if (on) {
			destroyCharts();
			['#e7rta-summary', '#e7rta-tags', '#e7rta-formstrip', '#e7rta-recent-boxes', '#e7rta-knobs', '#e7rta-session-stats', '#e7rta-session-nav', '#e7rta-tabpanel'].forEach(function (s) { clear($(s)); });
			renderBanner();
		}
	}
	function render() {
		if (!state.view) { setEmpty(true); return; }
		setEmpty(false);
		renderBanner();
		renderSummary();
		renderTags();
		renderRecent();
		renderKnobs();
		destroyCharts();
		buildTablist();
		renderTab();
		renderRankPoints();
		renderJourney();
		renderSessions();
		scheduleFlush();
	}

	function mount(rootEl, opts) {
		ROOT = rootEl; OPTS = opts || {};
		rootEl.classList.add('e7rta');
		rootEl.innerHTML =
			'<header class="e7rta-top"><p class="e7rta-sub" id="e7rta-identity"></p>' +
			'<div class="e7rta-topctl"><div class="e7rta-seg" id="e7rta-season" role="group" aria-label="Season"></div><button class="e7rta-close" id="e7rta-close" type="button" aria-label="Close analysis">✕</button></div></header>' +
			'<div class="e7rta-layout">' +
				'<aside class="e7rta-rail">' +
					'<section class="e7rta-banner" id="e7rta-banner"><img class="e7rta-avatar" id="e7rta-avatar" alt="" /><div class="e7rta-who"><h2 class="e7rta-name" id="e7rta-name"></h2><p class="e7rta-meta" id="e7rta-meta"></p></div><img class="e7rta-emblem" id="e7rta-emblem" alt="" /><div class="e7rta-tierbox"><span class="e7rta-tiername" id="e7rta-tiername"></span><span class="e7rta-points" id="e7rta-points"></span></div></section>' +
					'<section class="e7rta-card"><h3 class="e7rta-cardtitle">Season summary</h3><dl class="e7rta-stats" id="e7rta-summary"></dl></section>' +
					'<section class="e7rta-card"><h3 class="e7rta-cardtitle">Tags</h3><div class="e7rta-taglist" id="e7rta-tags"></div></section>' +
				'</aside>' +
				'<main class="e7rta-main">' +
					'<div class="e7rta-col">' +
						'<section class="e7rta-card"><h3 class="e7rta-cardtitle">Recent form <em id="e7rta-recent-sub"></em></h3><div class="e7rta-formstrip" id="e7rta-formstrip"></div><div class="e7rta-boxes" id="e7rta-recent-boxes"></div><div class="e7rta-knobs" id="e7rta-knobs"></div></section>' +
						'<section class="e7rta-card"><h3 class="e7rta-cardtitle">Sessions</h3><p class="e7rta-sub">Click a bar to inspect that session on the Sessions tab.</p><div class="e7rta-chips" id="e7rta-session-stats"></div><div class="e7rta-canvaswrap e7rta-canvaswrap--sessions"><canvas id="e7rta-c-sessions"></canvas></div><div class="e7rta-chips" id="e7rta-session-nav"></div></section>' +
					'</div>' +
					'<div class="e7rta-col">' +
						'<section class="e7rta-card"><h3 class="e7rta-cardtitle">Rank points <em id="e7rta-rankpoints-sub"></em></h3><div class="e7rta-canvaswrap e7rta-canvaswrap--sm"><canvas id="e7rta-c-rankpts"></canvas></div></section>' +
						'<section class="e7rta-card"><h3 class="e7rta-cardtitle">Ranked journey</h3><div class="e7rta-canvaswrap e7rta-canvaswrap--journey"><canvas id="e7rta-c-journey"></canvas></div></section>' +
					'</div>' +
				'</main>' +
				'<div class="e7rta-empty" id="e7rta-empty" hidden><p>No ranked battles captured for this player yet.</p><p class="e7rta-sub">Give the match history a moment to load, or open a different player.</p></div>' +
			'</div>' +
			'<section class="e7rta-tabs"><div class="e7rta-tablist" role="tablist" id="e7rta-tablist"></div><div class="e7rta-tabpanel" id="e7rta-panel" role="tabpanel"></div></section>' +
			'<div class="e7rta-tooltip" id="e7rta-tooltip" hidden></div>';

		TIP = $('#e7rta-tooltip');
		setupChartDefaults();
		$('#e7rta-close').addEventListener('click', function () { if (OPTS.onClose) OPTS.onClose(); });
	}

	function update(data, profile) {
		state.data = data;
		if (profile !== undefined) state.profile = profile;
		var preferred = null;
		for (var i = 0; i < data.views.length; i++) if (data.views[i].key !== 'all') { preferred = data.views[i]; break; }
		state.view = preferred || data.views[0] || null;
		state.session = state.view && state.view.sessions.length ? state.view.sessions.length - 1 : 0;
		state.tab = 'heroes';
		renderSeasonFilter();
		render();
	}

	window.E7Render = { mount: mount, update: update };
})();
